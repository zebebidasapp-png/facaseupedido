# Zé Bebidas - Catálogo Online

Catálogo de bebidas com delivery, carrinho de compras, histórico de pedidos e clientes.

## Funcionalidades

- **Vitrine de Produtos** com fotos, preços e promoções
- **Carrinho de Compras** com múltiplos produtos
- **Checkout** com formulário completo (nome, telefone, endereço, pagamento)
- **Promoções por Quantidade** (Leve X Pague Y / Desconto %)
- **Painel Administrativo** protegido por senha
- **Histórico de Pedidos** com status
- **Histórico de Clientes** com estatísticas
- **Exportar para Excel** (CSV)
- **PWA** - pode ser instalado no celular/PC
- **Funciona Offline**

## Como Instalar no Celular/PC

1. Abra o link do catálogo no navegador (Chrome/Edge)
2. Clique no menu (3 pontos) → "Adicionar à tela inicial" ou "Instalar aplicativo"
3. O ícone do Zé Bebidas aparecerá na sua tela inicial

## Acesso Administrativo

- Senha: `0923`

## Tecnologias

- HTML5, CSS3, JavaScript
- IndexedDB (banco de dados local)
- Service Worker (funcionamento offline)
- PWA (Progressive Web App)

---

**Zé Bebidas - Delivery de Bebidas**
